// ReportService.js

class ReportService {
    // static async getRouteRevenueReport() {
    //   // // Implement API call to fetch route revenue report data
    //   // // Example using fetch:
    //   // const response = await fetch('/api/reports/route-revenue');
  
    //   // if (!response.ok) {
    //   //   throw new Error('Failed to fetch route revenue report');
    //   // }
  
    //   // const data = await response.json();
    //   // return data;
    // }
  
    // static async getMerchantRevenueReport() {
    //   // // Implement API call to fetch merchant revenue report data
    //   // // Example using fetch:
    //   // const response = await fetch('/api/reports/merchant-revenue');
  
    //   // if (!response.ok) {
    //   //   throw new Error('Failed to fetch merchant revenue report');
    //   // }
  
    //   // const data = await response.json();
    //   // return data;
    // }
  
    // static async getBusRevenueReport() {
    //   // // Implement API call to fetch bus revenue report data
    //   // // Example using fetch:
    //   // const response = await fetch('/api/reports/bus-revenue');
  
    //   // if (!response.ok) {
    //   //   throw new Error('Failed to fetch bus revenue report');
    //   // }
  
    //   // const data = await response.json();
    //   // return data;
    // }
  
    // static async getConsumptionReport() {
    //   // // Implement API call to fetch consumption report data
    //   // // Example using fetch:
    //   // const response = await fetch('/api/reports/consumption');
  
    //   // if (!response.ok) {
    //   //   throw new Error('Failed to fetch consumption report');
    //   // }
  
    //   // const data = await response.json();
    //   // return data;
    // }
  }
  
  export default ReportService;
  