// auth.js

class Auth {
  static setToken(token) {
    // Implement the logic to store the authentication token, for example, in localStorage.
    localStorage.setItem('token', token);
  }

  static getToken() {
    // Implement the logic to retrieve the authentication token.
    return localStorage.getItem('token');
  }

  static isAuthenticated() {
    // Implement the logic to check if the user is authenticated, for example, by checking the presence of a token.
    return !!this.getToken();
  }

  static logout() {
    // Implement the logic to clear the authentication token, for example, remove it from localStorage.
    localStorage.removeItem('token');
  }
}

export default Auth;
