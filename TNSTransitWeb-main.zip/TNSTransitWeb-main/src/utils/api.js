// api.js

// const BASE_URL = 'https://api.example.com'; // Replace with your API base URL

const api = {
//   async get(endpoint) {
//     const response = await fetch(`${BASE_URL}${endpoint}`, {
//       method: 'GET',
//       headers: {
//         'Content-Type': 'application/json',
//         // Include any headers needed for your API requests (e.g., authentication token)
//       },
//     });

//     if (!response.ok) {
//       throw new Error(`Failed to fetch data from ${endpoint}`);
//     }

//     return response.json();
//   },

//   async post(endpoint, data) {
//     const response = await fetch(`${BASE_URL}${endpoint}`, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         // Include any headers needed for your API requests (e.g., authentication token)
//       },
//       body: JSON.stringify(data),
//     });

//     if (!response.ok) {
//       throw new Error(`Failed to post data to ${endpoint}`);
//     }

//     return response.json();
//   },

//   // Implement other HTTP methods (PUT, DELETE, etc.) as needed
};

export default api;
