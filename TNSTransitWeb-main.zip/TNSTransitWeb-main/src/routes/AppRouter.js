// // AppRouter.js

// import React from 'react';
// import {  BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// // import { Routes, Route } from 'react-router-dom';
// import LoginPage from '../views/Security/LoginPage';
// import RegistrationPage from '../views/Security/RegistrationPage';
// import ReportPage from '../views/Report/ReportPage';
// import RouteManagementPage from '../views/RouteManagement/RouteManagementPage';
// import PrivateRoute from './PrivateRoute';
// import Dashboard from '../pages/Dashboard';

// const AppRouter = () => {
//   return (
//     <Router>
//       <Routes> 
//         <Route path="/" element={<LoginPage />} />
//         {/* <Route path="/login" element={<LoginPage />} /> */}
//         <Route path="/dashboard/*" index element={<Dashboard />} />
//         {/* <Route path="/dashboard/*" element={<Dashboard />} /> */}
//         <Route path="/register" element={<RegistrationPage />} />
//         {/* <Route path="/reports" element={<PrivateRoute component={ReportPage} />} /> */}
//         {/* <Route path="/route-management" element={<PrivateRoute component={RouteManagementPage} />} /> */}
//         {/* Add other routes as needed */}
//       </Routes>
//     </Router>
 
//   );
// };

// export default AppRouter;
