const path = require('path');

module.exports = {
  entry: './src/index.js', // Adjust the entry file accordingly
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist'), // Adjust the output directory accordingly
  },
  module: {
    rules: [
      // Add your webpack loaders here as needed
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
        },
      },
    ],
  },
  resolve: {
    alias: {
      'xlsx': require.resolve('xlsx'),
    },
    fallback: {
      fs: false,
      path: false,
    },
  },
};
