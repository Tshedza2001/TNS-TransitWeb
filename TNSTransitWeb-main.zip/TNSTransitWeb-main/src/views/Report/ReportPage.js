// ReportPage.js

import React from 'react';
import ReportService from '../../services/ReportService';
// import { RouteRevenueReport, MerchantRevenueReport, BusRevenueReport, ConsumptionReport } from '../../components/Report';
import RouteRevenueReport from '../../components/Report/RouteRevenueReport';
import MerchantRevenueReport from '../../components/Report/MerchantRevenueReport';
import BusRevenueReport from '../../components/Report/BusRevenueReport';
import ConsumptionReport from '../../components/Report/ConsumptionReport';

// import ReportPage from '../../views/Report';

const ReportPage = () => {
  return (
    <div>
      <h2>Report Page</h2>
      <RouteRevenueReport data={ReportService.getRouteRevenueReport()} />
      <MerchantRevenueReport data={ReportService.getMerchantRevenueReport()} />
      <BusRevenueReport data={ReportService.getBusRevenueReport()} />
      <ConsumptionReport data={ReportService.getConsumptionReport()} />
    </div>
  );
};

export default ReportPage;
