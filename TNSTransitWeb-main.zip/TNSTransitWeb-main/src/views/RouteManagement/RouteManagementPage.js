// RouteManagementPage.js

import React from 'react';
// import { CreateRoute, ListRoute } from '../components/RouteManagement';
import CreateRoute from '../../components/RouteManagement/CreateRoute';
import ListRoute from '../../components/RouteManagement/ListRoute';
const RouteManagementPage = () => {
  return (
    <div>
      <h2>Route Management Page</h2>
      <CreateRoute />
      <ListRoute />
    </div>
  );
};

export default RouteManagementPage;
