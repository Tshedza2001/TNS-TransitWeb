// ListRoute.js

import React, { useEffect, useState } from 'react';
import RouteManagementService from '../../services/RouteManagementService';

const ListRoute = () => {
  const [routes, setRoutes] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch and display existing routes on component mount
    const fetchRoutes = async () => {
      try {
        const fetchedRoutes = await RouteManagementService.getRoutes();
        setRoutes(fetchedRoutes);
      } catch (error) {
        setError('Failed to fetch routes. Please try again.');
      }
    };

    fetchRoutes();
  }, []);

  return (
    <div>
      <h2>List Routes</h2>
      {routes.length === 0 ? (
        <p>No routes available.</p>
      ) : (
        <ul>
          {routes.map((route) => (
            <li key={route.id}>
              <strong>{route.routeName}</strong>
              <p>{route.routeDetails}</p>
            </li>
          ))}
        </ul>
      )}
      {error && <div style={{ color: 'red' }}>{error}</div>}
    </div>
  );
};

export default ListRoute;
