// CreateRoute.js

import React, { useState } from 'react';
import RouteManagementService from '../../services/RouteManagementService';

const CreateRoute = () => {
  const [routeName, setRouteName] = useState('');
  const [routeDetails, setRouteDetails] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState(null);

  const handleCreateRoute = async (e) => {
    e.preventDefault();
    setError(null);

    try {
      // Call the route management service to create a new route
      await RouteManagementService.createRoute({ routeName, routeDetails });
      setSuccessMessage('Route created successfully.');
      // Clear input fields after successful creation
      setRouteName('');
      setRouteDetails('');
    } catch (error) {
      setError('Failed to create route. Please try again.');
    }
  };

  return (
    <div>
      <h2>Create Route</h2>
      <form onSubmit={handleCreateRoute}>
        <div>
          <label htmlFor="routeName">Route Name:</label>
          <input
            type="text"
            id="routeName"
            value={routeName}
            onChange={(e) => setRouteName(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="routeDetails">Route Details:</label>
          <textarea
            id="routeDetails"
            value={routeDetails}
            onChange={(e) => setRouteDetails(e.target.value)}
            required
          ></textarea>
        </div>
        {successMessage && <div style={{ color: 'green' }}>{successMessage}</div>}
        {error && <div style={{ color: 'red' }}>{error}</div>}
        <button type="submit">Create Route</button>
      </form>
    </div>
  );
};

export default CreateRoute;
