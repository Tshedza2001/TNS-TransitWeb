// Registration.js

import React, { useState } from 'react';
import AuthenticationService from '../../services/AuthenticationService';

const Registration = () => {
  // const [username, setUsername] = useState('');
  // const [password, setPassword] = useState('');
  // const [confirmPassword, setConfirmPassword] = useState('');
  // const [error, setError] = useState(null);

  // const handleRegistration = async (e) => {
  //   e.preventDefault();
  //   setError(null);

  //   if (password !== confirmPassword) {
  //     setError('Passwords do not match.');
  //     return;
  //   }

  //   try {
  //     // Call the authentication service to handle registration
  //     await AuthenticationService.register(username, password);
  //     // Redirect to login page after successful registration
  //     // You might want to navigate the user to a different route or show a confirmation message
  //     alert('Registration successful. Please login.');
  //   } catch (error) {
  //     setError('Registration failed. Please try again.');
  //   }
  // };

  // return (
  //   <div>
  //     <h2>Registration</h2>
  //     <form onSubmit={handleRegistration}>
  //       <div>
  //         <label htmlFor="username">Username:</label>
  //         <input
  //           type="text"
  //           id="username"
  //           value={username}
  //           onChange={(e) => setUsername(e.target.value)}
  //           required
  //         />
  //       </div>
  //       <div>
  //         <label htmlFor="password">Password:</label>
  //         <input
  //           type="password"
  //           id="password"
  //           value={password}
  //           onChange={(e) => setPassword(e.target.value)}
  //           required
  //         />
  //       </div>
  //       <div>
  //         <label htmlFor="confirmPassword">Confirm Password:</label>
  //         <input
  //           type="password"
  //           id="confirmPassword"
  //           value={confirmPassword}
  //           onChange={(e) => setConfirmPassword(e.target.value)}
  //           required
  //         />
  //       </div>
  //       {error && <div style={{ color: 'red' }}>{error}</div>}
  //       <button type="submit">Register</button>
  //     </form>
  //   </div>
  // );
};

export default Registration;
